/*
 * main.c
 *
 *  Created on: Feb 10, 2011
 *      Author: tvluong
 */

#include "compiler.h"
#include "gpio.h"
#include "board.h"
#include "intc.h"
#include "pwm.h"
#include "tc.h"
#include "pm.h"
#include "pm_conf_clocks.h"
#include "adc.h"
#include "rtc.h"
#include "project_adc.h"
#include "project_motor.h"
#include "project_timer.h"
#include "project_usart.h"
#include "usart.h"
#include "Xbee_transceiver.h"
#include "LCD_lib_SD.h"
#include "util.h"
#include "power_clocks_lib.h"


//Buzzer PWM
#define PWM_PIN_INPUT_3				AVR32_PWM_2_PIN			//Pin PG03 on STK600, connect to pin 5 on L298N
#define PWM_FUNCTION_INPUT_3    	AVR32_PWM_2_FUNCTION
#define PWM_CHANNEL_ID_INPUT_3  	2



#define UI_count			Number_of_UIs



// possible values for configuring Panel_mode
#define Controller_box		0
#define Controller_UI_panel	1

// User interface addesses
#define UI1_16bit_Address_MSB  0x01
#define UI2_16bit_Address_MSB  0x02
#define UI3_16bit_Address_MSB  0x03
#define UI4_16bit_Address_MSB  0x04
#define UI5_16bit_Address_MSB  0x05



///////////////////////
// Need to configure //
///////////////////////
#define Panel_mode Controller_box
#define Panel_Address_MSB 	UI1_16bit_Address_MSB
#define CURRENT_ROOM		Panel_Address_MSB



//set the index of the data structure
#if Panel_Address_MSB == UI1_16bit_Address_MSB
#	define UI_data_index 0
#elif Panel_Address_MSB == UI2_16bit_Address_MSB
#	define UI_data_index 1
#elif Panel_Address_MSB == UI3_16bit_Address_MSB
#	define UI_data_index 2
#elif Panel_Address_MSB == UI4_16bit_Address_MSB
#	define UI_data_index 3
#elif Panel_Address_MSB == UI5_16bit_Address_MSB
#	define UI_data_index 4
#endif


#define GPIO_PIN_ENABLE				AVR32_PIN_PA18			//Pin PA02 on STK600, connect to pin 6 on L298N


#define PWM_PIN_INPUT_1				AVR32_PWM_0_PIN			//Pin PG03 on STK600, connect to pin 5 on L298N
#define PWM_PIN_INPUT_2				AVR32_PWM_1_PIN			//Pin PG04 on STK600, connect to pin 7 on L298N
#define PWM_FUNCTION_INPUT_1    	AVR32_PWM_0_FUNCTION
#define PWM_FUNCTION_INPUT_2    	AVR32_PWM_1_FUNCTION
#define PWM_CHANNEL_ID_INPUT_1  	0
#define PWM_CHANNEL_ID_INPUT_2  	1

measurement_storage data_measurement_real;
measurement_storage *data_measurement;

void update_data(void);
void check_for_data_request(void);

//For debugging purposes
char update() {

	const char str;

	int temp = readTemp();
	int valvePosition = get_valvePosition();
	int current = readCurrent();

    sprintf(str,"Valve Position: %d	Temp: %d Current: %d \n",valvePosition,temp,current);

	return str;
}





int main(void) {

	//startPWM(PWM_CHANNEL_ID_INPUT_3, PWM_PIN_INPUT_3, PWM_FUNCTION_INPUT_3, 5);



	// Initialize interrupt vectors.
	INTC_init_interrupts();

	// Initialize the Xbee unit
	data_measurement = &data_measurement_real;
	init_measurement(data_measurement);
	Init_Xbee();
	init_RX_Buffer();

	// Initialize the timer
	initCLOCK();


	// Controller Box code
	if(Panel_mode == Controller_box){

		int new_final_setPt = 0;
		int new_final_currentTemp = 0;
		int prev_final_setPt = 0;
		int prev_final_currentTemp = 0;


		// Initialize the motor
		initMotor();


		rotateMotor(360,1);

		timer_sec(5);

		rotateMotor(360,0);



		while (1){

			update_data();


			//Find the average set point and the average current temp
			int panel_i =0 ;
			int setPt_sum = 0;
			int currentTemp_sum = 0;
			double weight = 0;

			for(panel_i=0; panel_i < UI_count; panel_i++) {

				switch(UI_count){

				case(1):
						weight = 1;
				break;
				case(2):
						switch(panel_i){
								case (0): weight = .4; break;
								case (1): weight = .6; break;
						}
				break;
				case(3):
						switch(panel_i){
								case (0): weight = .3; break;
								case (1): weight = .4; break;
								case (2): weight = .3; break;
						}
				break;
				case(4):
						switch(panel_i){
								case (0): weight = .2; break;
								case (1): weight = .3; break;
								case (2): weight = .3; break;
								case (3): weight = .2; break;
						}
				break;
				case(5):
						switch(panel_i){
								case (0): weight = .15; break;
								case (1): weight = .2; break;
								case (2): weight = .3; break;
								case (3): weight = .2; break;
								case (4): weight = .15; break;
						}
				break;

				}


				currentTemp_sum = currentTemp_sum + data_measurement->curr_temp_measurement_UI[panel_i];
				setPt_sum = setPt_sum + weight*data_measurement->set_pt_measurement_UI[panel_i];
			}


			new_final_currentTemp = (currentTemp_sum/UI_count);
			new_final_setPt = setPt_sum;


			if(new_final_currentTemp != prev_final_currentTemp || new_final_setPt != prev_final_setPt){
				setTemp(new_final_setPt, new_final_currentTemp);
				prev_final_currentTemp = new_final_currentTemp;
				prev_final_setPt = new_final_setPt;
			}

			timer_sec(20);

		}
	}

	// Controller Panel UI code
	else if (Panel_mode == Controller_UI_panel) {

		// Initialize LCD
		initialSetupLCD();

		// Initialize push button interrupt
		init_Push_Button();

		int LCD_update_counter = 0;
		int backlighting_flag = 0;
		int backlighting_counter = 0;



		while (1) {

			check_for_data_request();

			if(data_measurement->set_pt_measurement_UI[UI_data_index] != get_setPt())
			{

				data_measurement->curr_temp_measurement_UI[UI_data_index] = readTemp();
				data_measurement->set_pt_measurement_UI[UI_data_index] = get_setPt();

				gpio_set_gpio_pin(AVR32_PIN_PB22);

				update_LCD_set_pt(data_measurement->set_pt_measurement_UI[UI_data_index]);
				backlighting_flag = 1;
				backlighting_counter = 0;
			}

			if(backlighting_flag == 1){
				backlighting_counter++;
			}

			if(backlighting_counter == 3000){
				gpio_clr_gpio_pin(AVR32_PIN_PB22);
				backlighting_flag = 0;
				backlighting_counter = 0;
			}


			if(LCD_update_counter == 3000){

				update_LCD_current_temp(readTemp());
				LCD_update_counter = 0;

			}


			LCD_update_counter++;
		}

	}


	return 1;

}

void check_for_data_request(void) {

	volatile unsigned char data_received_new = 0;

	// Defaults
	int current_temp = 0;
	int setpoint_temp = 65;

	data_received_new = dequeue_Rx_Buffer();

	if (data_received_new == CURRENT_ROOM) {
		current_temp = readTemp();
		data_measurement->curr_temp_measurement_UI[UI_data_index] = current_temp;
		setpoint_temp = get_setPt();
		data_measurement->set_pt_measurement_UI[UI_data_index] = setpoint_temp;
		Send_Message_Transparent(CURRENT_ROOM,current_temp, setpoint_temp);
		data_received_new = 0;
	}

}

void update_data(void) {

	int i = 0;

	for (i = 1; i <= UI_count; i++) {

		request_data(i);
		dequeue(data_measurement);

		timer_sec(2);
	}
}

