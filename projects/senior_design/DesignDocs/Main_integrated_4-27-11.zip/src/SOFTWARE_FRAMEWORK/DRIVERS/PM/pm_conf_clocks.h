/*
 * pm_conf_clocks.h
 *
 *  Created on: Apr 12, 2011
 *      Author: tvluong
 */

#ifndef PM_CONF_CLOCKS_H_
#define PM_CONF_CLOCKS_H_


#include "pm.h"


int pm_configure_clocks(pm_freq_param_t *param);

#endif /* PM_CONF_CLOCKS_H_ */
