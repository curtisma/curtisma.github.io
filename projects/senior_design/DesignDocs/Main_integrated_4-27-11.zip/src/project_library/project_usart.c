/*
 * project_usart.c
 *
 *  Created on: Feb 10, 2011
 *      Author: tvluong
 */


/* Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 *
 */



#include <avr32/io.h>
#include "compiler.h"
#include "board.h"
#include "power_clocks_lib.h"
#include "gpio.h"
#include "usart.h"


/*! \name USART Settings
 */
//! @{

#  define EXAMPLE_TARGET_PBACLK_FREQ_HZ FOSC0  // PBA clock target frequency, in Hz

#if BOARD == EVK1100
#  define EXAMPLE_USART               (&AVR32_USART2)
#  define EXAMPLE_USART_RX_PIN        AVR32_USART2_RXD_0_0_PIN 		//PH05 on STK600
#  define EXAMPLE_USART_RX_FUNCTION   AVR32_USART2_RXD_0_0_FUNCTION
#  define EXAMPLE_USART_TX_PIN        AVR32_USART2_TXD_0_0_PIN		//PH06 on STK600
#  define EXAMPLE_USART_TX_FUNCTION   AVR32_USART2_TXD_0_0_FUNCTION
#  define EXAMPLE_USART_CLOCK_MASK    AVR32_USART2_CLK_PBA
#  define EXAMPLE_PDCA_CLOCK_HSB      AVR32_PDCA_CLK_HSB
#  define EXAMPLE_PDCA_CLOCK_PB       AVR32_PDCA_CLK_PBA
#elif BOARD == EVK1101
#  define EXAMPLE_USART               (&AVR32_USART1)
#  define EXAMPLE_USART_RX_PIN        AVR32_USART1_RXD_0_0_PIN
#  define EXAMPLE_USART_RX_FUNCTION   AVR32_USART1_RXD_0_0_FUNCTION
#  define EXAMPLE_USART_TX_PIN        AVR32_USART1_TXD_0_0_PIN
#  define EXAMPLE_USART_TX_FUNCTION   AVR32_USART1_TXD_0_0_FUNCTION
#  define EXAMPLE_USART_CLOCK_MASK    AVR32_USART1_CLK_PBA
#  define EXAMPLE_PDCA_CLOCK_HSB      AVR32_PDCA_CLK_HSB
#  define EXAMPLE_PDCA_CLOCK_PB       AVR32_PDCA_CLK_PBA
#elif BOARD == UC3C_EK
#  define EXAMPLE_USART               (&AVR32_USART2)
#  define EXAMPLE_USART_RX_PIN        AVR32_USART2_RXD_0_1_PIN
#  define EXAMPLE_USART_RX_FUNCTION   AVR32_USART2_RXD_0_1_FUNCTION
#  define EXAMPLE_USART_TX_PIN        AVR32_USART2_TXD_0_1_PIN
#  define EXAMPLE_USART_TX_FUNCTION   AVR32_USART2_TXD_0_1_FUNCTION
#  define EXAMPLE_USART_CLOCK_MASK    AVR32_USART2_CLK_PBA
#  define EXAMPLE_PDCA_CLOCK_HSB      AVR32_PDCA_CLK_HSB
#  define EXAMPLE_PDCA_CLOCK_PB       AVR32_PDCA_CLK_PBB
#elif BOARD == EVK1104
#  define EXAMPLE_USART               (&AVR32_USART1)
#  define EXAMPLE_USART_RX_PIN        AVR32_USART1_RXD_0_0_PIN
#  define EXAMPLE_USART_RX_FUNCTION   AVR32_USART1_RXD_0_0_FUNCTION
#  define EXAMPLE_USART_TX_PIN        AVR32_USART1_TXD_0_0_PIN
#  define EXAMPLE_USART_TX_FUNCTION   AVR32_USART1_TXD_0_0_FUNCTION
#  define EXAMPLE_USART_CLOCK_MASK    AVR32_USART1_CLK_PBA
#  define EXAMPLE_PDCA_CLOCK_HSB      AVR32_PDCA_CLK_HSB
#  define EXAMPLE_PDCA_CLOCK_PB       AVR32_PDCA_CLK_PBA
#elif BOARD == EVK1105
#  define EXAMPLE_USART               (&AVR32_USART0)
#  define EXAMPLE_USART_RX_PIN        AVR32_USART0_RXD_0_0_PIN
#  define EXAMPLE_USART_RX_FUNCTION   AVR32_USART0_RXD_0_0_FUNCTION
#  define EXAMPLE_USART_TX_PIN        AVR32_USART0_TXD_0_0_PIN
#  define EXAMPLE_USART_TX_FUNCTION   AVR32_USART0_TXD_0_0_FUNCTION
#  define EXAMPLE_USART_CLOCK_MASK    AVR32_USART0_CLK_PBA
#  define EXAMPLE_PDCA_CLOCK_HSB      AVR32_PDCA_CLK_HSB
#  define EXAMPLE_PDCA_CLOCK_PB       AVR32_PDCA_CLK_PBA
#elif BOARD == STK600_RCUC3L0
#  define EXAMPLE_USART               (&AVR32_USART1)
#  define EXAMPLE_USART_RX_PIN        AVR32_USART1_RXD_0_1_PIN
#  define EXAMPLE_USART_RX_FUNCTION   AVR32_USART1_RXD_0_1_FUNCTION
// For the RX pin, connect STK600.PORTE.PE3 to STK600.RS232 SPARE.RXD
#  define EXAMPLE_USART_TX_PIN        AVR32_USART1_TXD_0_1_PIN
#  define EXAMPLE_USART_TX_FUNCTION   AVR32_USART1_TXD_0_1_FUNCTION
// For the TX pin, connect STK600.PORTE.PE2 to STK600.RS232 SPARE.TXD
#  define EXAMPLE_USART_CLOCK_MASK    AVR32_USART1_CLK_PBA
#  define EXAMPLE_PDCA_CLOCK_HSB      AVR32_PDCA_CLK_HSB
#  define EXAMPLE_PDCA_CLOCK_PB       AVR32_PDCA_CLK_PBA
#elif BOARD == UC3L_EK
#  define EXAMPLE_USART                 (&AVR32_USART3)
#  define EXAMPLE_USART_RX_PIN          AVR32_USART3_RXD_0_0_PIN
#  define EXAMPLE_USART_RX_FUNCTION     AVR32_USART3_RXD_0_0_FUNCTION
#  define EXAMPLE_USART_TX_PIN          AVR32_USART3_TXD_0_0_PIN
#  define EXAMPLE_USART_TX_FUNCTION     AVR32_USART3_TXD_0_0_FUNCTION
#  define EXAMPLE_USART_CLOCK_MASK      AVR32_USART3_CLK_PBA
#  define EXAMPLE_TARGET_DFLL_FREQ_HZ   96000000  // DFLL target frequency, in Hz
#  define EXAMPLE_TARGET_MCUCLK_FREQ_HZ 12000000  // MCU clock target frequency, in Hz
#  undef  EXAMPLE_TARGET_PBACLK_FREQ_HZ
#  define EXAMPLE_TARGET_PBACLK_FREQ_HZ 12000000  // PBA clock target frequency, in Hz
#  define EXAMPLE_PDCA_CLOCK_HSB      AVR32_PDCA_CLK_HSB
#  define EXAMPLE_PDCA_CLOCK_PB       AVR32_PDCA_CLK_PBA
#endif

#if !defined(EXAMPLE_USART)             || \
    !defined(EXAMPLE_USART_RX_PIN)      || \
    !defined(EXAMPLE_USART_RX_FUNCTION) || \
    !defined(EXAMPLE_USART_TX_PIN)      || \
    !defined(EXAMPLE_USART_TX_FUNCTION)
#  error The USART configuration to use in this example is missing.
#endif

//! @}


#if BOARD == UC3L_EK
/*! \name Parameters to pcl_configure_clocks().
 */
//! @{
static scif_gclk_opt_t gc_dfllif_ref_opt = { SCIF_GCCTRL_SLOWCLOCK, 0, OFF };
static pcl_freq_param_t pcl_dfll_freq_param =
{
  .main_clk_src = PCL_MC_DFLL0,
  .cpu_f        = EXAMPLE_TARGET_MCUCLK_FREQ_HZ,
  .pba_f        = EXAMPLE_TARGET_PBACLK_FREQ_HZ,
  .pbb_f        = EXAMPLE_TARGET_PBACLK_FREQ_HZ,
  .dfll_f       = EXAMPLE_TARGET_DFLL_FREQ_HZ,
  .pextra_params = &gc_dfllif_ref_opt
};
//! @}
#endif


void initUSART(void) {

	static const gpio_map_t USART_GPIO_MAP =
	  {
	    {EXAMPLE_USART_RX_PIN, EXAMPLE_USART_RX_FUNCTION},
	    {EXAMPLE_USART_TX_PIN, EXAMPLE_USART_TX_FUNCTION}
	  };

	  // USART options.
	  static const usart_options_t USART_OPTIONS =
	  {
	    .baudrate     = 1200,
	    .charlength   = 8,
	    .paritytype   = USART_NO_PARITY,
	    .stopbits     = USART_1_STOPBIT,
	    .channelmode  = USART_NORMAL_CHMODE
	  };


	#if BOARD == UC3L_EK
	  // Note: on the AT32UC3L-EK board, there is no crystal/external clock connected
	  // to the OSC0 pinout XIN0/XOUT0. We shall then program the DFLL and switch the
	  // main clock source to the DFLL.
	  pcl_configure_clocks(&pcl_dfll_freq_param);
	  // Note: since it is dynamically computing the appropriate field values of the
	  // configuration registers from the parameters structure, this function is not
	  // optimal in terms of code size. For a code size optimal solution, it is better
	  // to create a new function from pcl_configure_clocks_dfll0() and modify it
	  // to use preprocessor computation from pre-defined target frequencies.
	#else
	  // Configure Osc0 in crystal mode (i.e. use of an external crystal source, with
	  // frequency FOSC0) with an appropriate startup time then switch the main clock
	  // source to Osc0.
	//pm_switch_to_osc0(&AVR32_PM, FOSC0, OSC0_STARTUP);

	  //pcl_switch_to_osc(PCL_OSC0, FOSC0, OSC0_STARTUP);
	#endif

	  // Assign GPIO to USART.
	  gpio_enable_module(USART_GPIO_MAP,
	                     sizeof(USART_GPIO_MAP) / sizeof(USART_GPIO_MAP[0]));

	  // Initialize USART in RS232 mode.
	  usart_init_rs232(EXAMPLE_USART, &USART_OPTIONS, EXAMPLE_TARGET_PBACLK_FREQ_HZ);


}
