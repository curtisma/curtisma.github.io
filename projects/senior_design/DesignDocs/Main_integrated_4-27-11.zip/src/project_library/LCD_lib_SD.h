#include "gpio.h"
#include "compiler.h"
#include "board.h"
#include "intc.h"
#include "pm.h"


//---------------------------------------------------------------
// CONSTANTS
//---------------------------------------------------------------

#define DISPOFF      0xAE
#define DISPON       0xAF
#define DISPSTART    0x40
#define PAGEADR      0xB0
#define COLADRL      0x00
#define COLADRH      0x10
#define ADCNORMAL    0xA0
#define ADCREVERSE   0xA1
#define COMNORMAL    0xC0
#define COMREVERSE   0xC8
#define DISPNORMAL   0xA6
#define DISPREVERSE  0xA7
#define LCDBIAS9     0xA2
#define LCDBIAS7     0xA3
#define RESET        0xE2
#define SETPOWERCTRL 0x2F
#define REGRESISTOR  0x27
#define SETCONTRAST  0x81
#define STATINDMODE  0xAC
#define BOOSTERRATIO 0xF8


//---------------------------------------------------------------
// PIN DEFINITION
//---------------------------------------------------------------

#define DOGCSPIN	AVR32_PIN_PA10     //stk600 pb2

#define DOGRESPIN	AVR32_PIN_PA19     //stk600 pc3

#define DOGA0PIN	AVR32_PIN_PA14     //stk600 pb6

#define DOGSCLPIN	AVR32_PIN_PA13     //stk600 pb5

#define DOGSIPIN	AVR32_PIN_PA12     //stk600 pb4


//---------------------------------------------------------------
// SPI SETUP DEFINITION
//---------------------------------------------------------------

#define SetBit(adr, bnr)	( (adr) |=  (1 << (bnr)) )
#define ClrBit(adr, bnr)	( (adr) &= ~(1 << (bnr)) )

#define	DOGENABLE  gpio_clr_gpio_pin(DOGCSPIN)
#define	DOGDISABLE gpio_set_gpio_pin(DOGCSPIN)

#define	DOGCOMMAND gpio_clr_gpio_pin(DOGA0PIN)
#define	DOGDATA    gpio_set_gpio_pin(DOGA0PIN)

#define	DOG_CLK_HIGH 	gpio_set_gpio_pin(DOGSCLPIN)
#define	DOG_CLK_LOW      gpio_clr_gpio_pin(DOGSCLPIN)

#define	DOG_SI_HIGH 	gpio_set_gpio_pin(DOGSIPIN)
#define	DOG_SI_LOW      gpio_clr_gpio_pin(DOGSIPIN)

#define DOG_RES			gpio_clr_gpio_pin(DOGRESPIN)
#define DOG_RES_DISB	gpio_set_gpio_pin(DOGRESPIN)


extern void dogSPIout(unsigned char out);
extern void initDOGM128(void);
extern void ResetDOG(void);
extern void DogKontrast(char contrast);
extern void int2byte(int zeroTo255);
extern void PageSelect(unsigned char page);
extern void Reset(void);
extern void LineSelect(unsigned char line);
extern void ColumnSelect(unsigned char column);
extern void ClearDisplay(void);
extern void Display_ON(void);
extern void Display_OFF(void);
extern void ClearDisplay1(void);
extern void ISU_Logo(void);
extern void BATT_Charging(void);
extern void Template(void);
extern void BattLogo(void);
extern void BattLow(void);
extern void ClearBattLow(void);
extern void MON(void);
extern void TUE(void);
extern void WED(void);
extern void THUR(void);
extern void FRI(void);
extern void SAT(void);
extern void SUN(void);
extern void ClearDay(void);
extern void TimeNums(char zero2nine, char zero2three);
extern void AM_PM(char AM_Zero_Or_PM_One);
extern void semicolon(void);
extern void ClrTimeNums(char zero2three);
extern void SetTempNums(char zero2nine, char zero2one);
extern void ClrSetTempNums(char zero2one);
extern void CurTempNums(char zero2nine, char zero2one);
extern void ClrCurTempNums(char zero2one);
extern void promptDate(void);
extern void promptTime(void);
extern void initialSetupLCD(void);
extern void update_LCD_current_temp(unsigned char curTemp);
extern void update_LCD_set_pt(unsigned char setPt);
