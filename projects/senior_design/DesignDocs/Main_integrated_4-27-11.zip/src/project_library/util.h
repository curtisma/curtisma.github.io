/*
 * util.h
 *
 *  Created on: Apr 10, 2011
 *      Author: tvluong
 */

#ifndef UTIL_H_
#define UTIL_H_

extern void init_Push_Button(void);

extern int get_setPt(void);

extern void startBuzzer(void);

extern void stopBuzzer(void);

#endif /* UTIL_H_ */
