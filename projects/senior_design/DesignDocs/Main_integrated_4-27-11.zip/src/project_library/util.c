
/* Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 *
 */

#include "compiler.h"
#include "gpio.h"
#include "board.h"
#include "intc.h"
#include "pwm.h"
#include "tc.h"
#include "pm.h"
#include "adc.h"
#include "rtc.h"
#include "project_adc.h"
#include "project_timer.h"
#include "power_clocks_lib.h"
#include "usart.h"
#include "project_usart.h"
#include "Xbee_transceiver.h"



#define PUSHBUTTON_UP 	AVR32_PIN_PA17 // AVR32_PIN_PA02 //STK600
#define PUSHBUTTON_DOWN AVR32_PIN_PA16 // AVR32_PIN_PA04 // STK600

//Buzzer PWM
#define PWM_PIN_INPUT_3				AVR32_PWM_2_PIN			//Pin PG03 on STK600, connect to pin 5 on L298N
#define PWM_FUNCTION_INPUT_3    	AVR32_PWM_2_FUNCTION
#define PWM_CHANNEL_ID_INPUT_3  	2


int UI_setpt;


/*
 * brief The read Channel A interrupt handler.
 */
#if __GNUC__
__attribute__((__interrupt__))
#elif __ICCAVR32__
__interrupt
#endif


static void pushButton(void) {

	if (gpio_get_pin_interrupt_flag(PUSHBUTTON_UP)) {
		if(UI_setpt < 80) {
			 UI_setpt++;
		} else if (UI_setpt >= 80){
			UI_setpt = 80;
		}
		gpio_clear_pin_interrupt_flag(PUSHBUTTON_UP);

	}

	if (gpio_get_pin_interrupt_flag(PUSHBUTTON_DOWN)) {
		if( UI_setpt > 60) {
			 UI_setpt--;
		} else if (UI_setpt <= 60){
			UI_setpt = 60;
		}
		gpio_clear_pin_interrupt_flag(PUSHBUTTON_DOWN);

	}



}



/*
 *
 * Set up interrupts
 *
 */
void init_Push_Button(void) {

	gpio_enable_pin_pull_up(PUSHBUTTON_UP);
	gpio_enable_pin_pull_up(PUSHBUTTON_DOWN);


	/* Disable all interrupts */
	Disable_global_interrupt();


	gpio_enable_pin_interrupt(PUSHBUTTON_UP, GPIO_FALLING_EDGE);
	gpio_enable_pin_interrupt(PUSHBUTTON_DOWN, GPIO_FALLING_EDGE);


	/* register readChanA on level 1 */
	INTC_register_interrupt(&pushButton, AVR32_GPIO_IRQ_2,
			 AVR32_INTC_INT0);

	/* Enable all interrupts */
	Enable_global_interrupt();

	UI_setpt = 70;




}
// Returns
int get_setPt(void) {
	return UI_setpt;
}


void startBuzzer(void){

	  pwm_opt_t pwm_opt;                                // PWM option config.
	  avr32_pwm_channel_t pwm_channel = { .ccnt = 0 };  // One channel config.

	  // The channel number and instance is used in several functions.
	  // It's defined as local variable for ease-of-use.
	  unsigned int channel_id;

	  channel_id = PWM_CHANNEL_ID_INPUT_3;
	  gpio_enable_module_pin(PWM_PIN_INPUT_3, PWM_FUNCTION_INPUT_3);

	  // PWM controller configuration.
	  pwm_opt.diva = AVR32_PWM_DIVA_CLK_OFF;
	  pwm_opt.divb = AVR32_PWM_DIVB_CLK_OFF;
	  pwm_opt.prea = AVR32_PWM_PREA_MCK;
	  pwm_opt.preb = AVR32_PWM_PREB_MCK;

	  pwm_init(&pwm_opt);

	  pwm_channel.CMR.calg = PWM_MODE_LEFT_ALIGNED;       // Channel mode.
	  pwm_channel.CMR.cpol = PWM_POLARITY_HIGH;            // Channel polarity.
	  pwm_channel.CMR.cpd = PWM_UPDATE_DUTY;              // Not used the first time.
	  pwm_channel.CMR.cpre = 1;  // Channel prescaler.
	  pwm_channel.cdty = 15;   // Channel duty cycle, should be < CPRD.
	  pwm_channel.cprd = 30;  // Channel period.
	  pwm_channel.cupd = 0;   // Channel update is not used here.
	  // With these settings, the output waveform period will be :
	  // (115200/256)/10 == 45Hz == (MCK/prescaler)/period, with MCK == 115200Hz,
	  // prescaler == 256, period == 20.

	  pwm_channel_init(channel_id, &pwm_channel); // Set channel configuration to channel 0.
	  pwm_start_channels(1 << channel_id);

}


void stopBuzzer(void){

	  pwm_opt_t pwm_opt;                                // PWM option config.
	  avr32_pwm_channel_t pwm_channel = { .ccnt = 0 };  // One channel config.

	  // The channel number and instance is used in several functions.
	  // It's defined as local variable for ease-of-use.
	  unsigned int channel_id;

	  channel_id = PWM_CHANNEL_ID_INPUT_3;
	  gpio_enable_module_pin(PWM_PIN_INPUT_3, PWM_FUNCTION_INPUT_3);

	  // PWM controller configuration.
	  pwm_opt.diva = AVR32_PWM_DIVA_CLK_OFF;
	  pwm_opt.divb = AVR32_PWM_DIVB_CLK_OFF;
	  pwm_opt.prea = AVR32_PWM_PREA_MCK;
	  pwm_opt.preb = AVR32_PWM_PREB_MCK;

	  pwm_init(&pwm_opt);

	  pwm_channel.CMR.calg = PWM_MODE_LEFT_ALIGNED;       // Channel mode.
	  pwm_channel.CMR.cpol = PWM_POLARITY_LOW;            // Channel polarity.
	  pwm_channel.CMR.cpd = PWM_UPDATE_DUTY;              // Not used the first time.
	  pwm_channel.CMR.cpre = 1;  // Channel prescaler.
	  pwm_channel.cdty = 0;   // Channel duty cycle, should be < CPRD.
	  pwm_channel.cprd = 30;  // Channel period.
	  pwm_channel.cupd = 0;   // Channel update is not used here.
	  // With these settings, the output waveform period will be :
	  // (115200/256)/20 == 22.5Hz == (MCK/prescaler)/period, with MCK == 115200Hz,
	  // prescaler == 256, period == 20.

	  pwm_channel_init(channel_id, &pwm_channel); // Set channel configuration to channel 0.
	  pwm_stop_channels(1 << channel_id);

}
