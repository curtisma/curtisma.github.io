/*
 * project_timer.c
 *
 *  Created on: Feb 10, 2011
 *      Author: tvluong
 */


/* Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 *
 */



#include "compiler.h"
#include "gpio.h"
#include "board.h"
#include "intc.h"
#include "pwm.h"
#include "tc.h"
#include "pm.h"
#include "adc.h"
#include "rtc.h"



// To specify we have to print a new time
volatile static int flag_sec = 0;
volatile static int flag_timer = 0;

// Time counter
static int timer_second = 0;
static int sec = 0;
static int min = 0;
static int hr = 0;


#if __GNUC__
__attribute__((__interrupt__))
#elif __ICCAVR32__
/* RTC Interrupt  */
#pragma handler = AVR32_RTC_IRQ_GROUP, 1
__interrupt
#endif

void rtc_irq(void)
{
  // Increment the sec, min, hr counter
  sec++;

  if(sec >= 60){
	  min++;
	  sec = 0;
  }

  if(min >= 60){
	  hr++;
	  min = 0;
  }

  if(hr >= 24){
	  hr = 0;
  }

  if(flag_timer){
	  timer_second++;
  }

  // clear the interrupt flag
  rtc_clear_interrupt(&AVR32_RTC);

  // specify that an interrupt has been raised
  flag_sec = 1;
}



void set_sec(int second){
	sec = second;
}

void set_min(int minute){
	min = minute;
}

void set_hr(int hour){
	hr = hour;
}

int get_sec(void){
	return sec;
}

int get_min(void){
	return min;
}

int get_hr(void){
	return hr;
}

void setTime(int hour, int minute, int second){
	set_hr(hour);
	set_min(minute);
	set_sec(second);

}

void initCLOCK(void){

	setTime(0,0,0);



				// Disable all interrupts. */
			    Disable_global_interrupt();

			    // The INTC driver has to be used only for GNU GCC for AVR32.
			  #if __GNUC__
			    // Initialize interrupt vectors.
			    //INTC_init_interrupts();

			    // Register the RTC interrupt handler to the interrupt controller.
			    INTC_register_interrupt(&rtc_irq, AVR32_RTC_IRQ, AVR32_INTC_INT2);
			  #endif

			    // Initialize the RTC
			    if (!rtc_init(&AVR32_RTC, RTC_OSC_RC, RTC_PSEL_RC_1_76HZ))
			    {
			      while(1);
			    }

			    // Set top value to 0 to generate an interrupt every seconds */
			    rtc_set_top_value(&AVR32_RTC, 0);

			    // Enable the interrupts
			    rtc_enable_interrupt(&AVR32_RTC);

			    // Enable the RTC
			    rtc_enable(&AVR32_RTC);


			    // Enable global interrupts
			    Enable_global_interrupt();

}





void timer_sec(int second){



	int end_time = second;
	timer_second = 0;

	flag_timer = 1;


		    while(1)
		    {
				if(timer_second >= end_time){
			    	timer_second = 0;
			    	flag_timer = 0;
					return;
				}


		    }


/*
	int k = 0;
	int l = 0;

	for(k = 0; k < second; k++){

		for(l = 0; l < 10000; l++){

		}
	}

*/
}


void timer_min(int minute){
	int i;
	for(i = 0; i < minute; i++){
		timer_sec(60);
	}
}



