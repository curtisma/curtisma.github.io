/*
 * main.c
 *
 *  Created on: Feb 10, 2011
 *      Author: tvluong
 */

#include "compiler.h"
#include "gpio.h"
#include "board.h"
#include "intc.h"
#include "pwm.h"
#include "tc.h"
#include "pm.h"
#include "adc.h"
#include "rtc.h"
#include "project_adc.h"
#include "project_motor.h"
#include "project_timer.h"
#include "project_usart.h"
#include "usart.h"
#include "Xbee_transceiver.h"


#define USART2              (&AVR32_USART2)
#define CURRENT_ROOM		UI_current_16bit_Address_MSB
#define UI_count			Number_of_UIs

measurement_storage data_measurement_real;
measurement_storage *data_measurement;


void wait_for_data_request(void){

	volatile unsigned char data_received_new = 0;

	int current_temp = 0;
	int setpoint_temp = 70;

	while(1){

		data_received_new = dequeue_Rx_Buffer();

		if(data_received_new == CURRENT_ROOM){

			current_temp = readTemp();

			Send_Message_Transparent(current_temp,setpoint_temp);

			data_received_new = 0;

		}

	}

}

void update_data(void){

	char message[100];


	int i = 0;

	for(i = 0; i < UI_count; i++){
		request_data(i);
		dequeue(data_measurement);

		sprintf(message,"%d %d ",data_measurement->curr_temp_measurement_UI[i],data_measurement->set_pt_measurement_UI[i]);
		usart_write_line(USART2, message);
		timer_sec(1);

	}


}


int main(void) {

	// Initialize interrupt vectors.
	INTC_init_interrupts();

	// Initialize the Xbee unit
	Init_Xbee();

	// Initialize the timer
	initCLOCK();

	// Initialize the USART for Hyperterminal
	initUSART();

	usart_write_line(USART2, "Begin Testing: \n");


	init_RX_Buffer();

	data_measurement = &data_measurement_real;
	init_measurement(data_measurement);

	while (1) {
		wait_for_data_request();
		update_data();
		timer_sec(5);
	}


	return 1;
}




