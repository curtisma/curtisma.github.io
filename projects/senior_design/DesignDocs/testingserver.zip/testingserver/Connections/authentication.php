<?php
# FileName="Connection_php_mysql.htm"
# Type="MYSQL"
# HTTP="true"
$hostname_authentication = "localhost";
$database_authentication = "authentication";
$username_authentication = "root";
$password_authentication = "";
$authentication = mysql_pconnect($hostname_authentication, $username_authentication, $password_authentication) or trigger_error(mysql_error(),E_USER_ERROR); 
?>