/* This source file is part of the ATMEL AVR32-UC3-SoftwareFramework-1.6.0 Release */

/*This file has been prepared for Doxygen automatic documentation generation.*/
/*! \file *********************************************************************
 *
 * \brief GPIO example application for AVR32 using the peripheral bus interface.
 *
 * - Compiler:           IAR EWAVR32 and GNU GCC for AVR32
 * - Supported devices:  All AVR32 devices with GPIO.
 * - AppNote:
 *
 * \author               Atmel Corporation: http://www.atmel.com \n
 *                       Support and FAQ: http://support.atmel.no/
 *
 *****************************************************************************/

/*! \page License
 * Copyright (c) 2009 Atmel Corporation. All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * 3. The name of Atmel may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 *
 * 4. This software may only be redistributed and used in connection with an Atmel
 * AVR product.
 *
 * THIS SOFTWARE IS PROVIDED BY ATMEL "AS IS" AND ANY EXPRESS OR IMPLIED
 * WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT ARE
 * EXPRESSLY AND SPECIFICALLY DISCLAIMED. IN NO EVENT SHALL ATMEL BE LIABLE FOR
 * ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE
 *
 */

/*! \mainpage
 * \section intro Introduction
 * This is the documentation for the data structures, functions, variables,
 * defines, enums, and typedefs for the GPIO driver.
 *
 * The General Purpose Input/Output manages the I/O pins of the microcontroller. Each I/O line
 * may be dedicated as a general-purpose I/O or be assigned to a function of an embedded peripheral.
 * This assures effective optimization of the pins of a product.
 *
 * The given example covers various uses of the GPIO controller and demonstrates
 * different GPIO functionalities using the peripheral bus interface. It uses a
 * LED and a button.
 *
 * This interface operates with lower clock frequencies (fPB <= fCPU), and its
 * timing is not deterministic since it needs to access a shared bus which may
 * be heavily loaded.
 *
 * \section files Main Files
 * - gpio.c: GPIO driver;
 * - gpio.h: GPIO driver header file;
 * - gpio_peripheral_bus_example.c: GPIO example application using the peripheral bus.
 *
 * \section compinfo Compilation Info
 * This software was written for the GNU GCC for AVR32 and IAR Systems compiler
 * for AVR32. Other compilers may or may not work.
 *
 * \section deviceinfo Device Info
 * All AVR32 devices with a GPIO module can be used. This example has been tested
 * with the following setup:
 *   - EVK1100, EVK1101, UC3C_EK, EVK1104 or EVK1105 evaluation kits
 *   - STK600+RCUC3L0 routing card: connect STK600.PORTA.PA4 to STK600.LEDS.LED0,
 *     STK600.PORTA.PA5 to STK600.LEDS.LED1, STK600.PORTD.PD2 to STK600.SWITCHES.SW0.
 *     Press and release SW0 to turn LED1 on/off. LED0 is automatically toggled by
 *     the application
 *   - AT32UC3L-EK: the A LED toggles forever and use the WAKE button to toggle the B LED.
 *
 *
 * \section setupinfo Setup Information
 * CPU speed: <i> Internal RC oscillator (about 115200 Hz) </i>.
 *
 * \section contactinfo Contact Information
 * For further information, visit
 * <A href="http://www.atmel.com/products/AVR32/">Atmel AVR32</A>.\n
 * Support and FAQ: http://support.atmel.no/
 */


#include "compiler.h"
#include "gpio.h"
#include "board.h"
#include "intc.h"
#include "pm.h"


/*! \name Pin Configuration
 */
//! @{
#define GPIO_PIN_EXAMPLE_1  LED0_GPIO
#define GPIO_PIN_EXAMPLE_2  LED1_GPIO

//! @}


/*!
 * \brief The Push Buttons interrupt handler.
 */
#if __GNUC__
__attribute__((__interrupt__))
#elif __ICCAVR32__
__interrupt
#endif

static void PushButton_int_handler(void) {

	if (gpio_get_pin_interrupt_flag(GPIO_PUSH_BUTTON_0)) {

		gpio_clr_gpio_pin(GPIO_PIN_EXAMPLE_1);
		gpio_clr_gpio_pin(GPIO_PIN_EXAMPLE_2);

		gpio_clear_pin_interrupt_flag(GPIO_PUSH_BUTTON_0);
	}

	if (gpio_get_pin_interrupt_flag(GPIO_PUSH_BUTTON_1)) {

		gpio_set_gpio_pin(GPIO_PIN_EXAMPLE_1);
		gpio_set_gpio_pin(GPIO_PIN_EXAMPLE_2);

		gpio_clear_pin_interrupt_flag(GPIO_PUSH_BUTTON_1);
	}

}


/*! \brief This is an example of how to access the gpio.c driver to set, clear, toggle... the pin GPIO_PIN_EXAMPLE.
 */
int main(void)
{

	/* Disable all interrupts */
	Disable_global_interrupt();

	gpio_enable_pin_interrupt(GPIO_PUSH_BUTTON_0, GPIO_FALLING_EDGE);
	gpio_enable_pin_interrupt(GPIO_PUSH_BUTTON_1, GPIO_FALLING_EDGE);

	// Initialize interrupt vectors.
	INTC_init_interrupts();

	/* register PushButton_int_handler on level 1 */
	INTC_register_interrupt(&PushButton_int_handler, AVR32_GPIO_IRQ_0,
			 AVR32_INTC_INT1);

	/* Enable all interrupts */
	Enable_global_interrupt();


	while (1)
	{
	    // If there is a chance that any PB write operations are incomplete, the CPU
	    // should perform a read operation from any register on the PB bus before
	    // executing the sleep instruction.
	    AVR32_INTC.ipr[0];  // Dummy read

	    // Go to FROZEN sleep mode.
	    SLEEP(AVR32_PM_SMODE_FROZEN);

	}

}
