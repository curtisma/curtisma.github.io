/*
 * LCD_lib_SD.h
 *
 *  Created on: Jan 5, 2011
 *      Author: tvluong
 */

#ifndef _LCD_H_
#define _LCD_H_

#include "gpio.h"
#include "compiler.h"
#include "board.h"
#include "intc.h"
#include "pm.h"

extern void dogSPIout(unsigned char out);

extern void initDOGM128(void);

extern void ResetDOG(void);

extern void DogKontrast(char contrast);

extern unsigned char int2byte(int zeroTo255);

extern void PageSelect(unsigned char page);

extern void Reset(void);

extern void LineSelect(unsigned char line);

extern void ColumnSelect(unsigned char column);

extern void ClearDisplay(void);

extern void Display_ON(void);

extern void Display_OFF(void);

extern void ClearDisplay1(void);

extern void ISU_Logo(void);

extern void BATT_Charging(void);

extern void Template(void);

extern void BattLogo(void);

extern void BattLow(void);

extern void ClearBattLow(void);

extern void MON(void);

extern void TUE(void);

extern void WED(void);

extern void THUR(void);

extern void FRI(void);

extern void SAT(void);

extern void SUN(void);

extern void ClearDay(void);

extern void TimeNums(char zero2nine, char zero2three);

extern void AM_PM(char AM_Zero_Or_PM_One);

extern void semicolon(void);

extern void ClrTimeNums(char zero2three);

extern void SetTempNums(char zero2nine, char zero2one);

extern void ClrSetTempNums(char zero2one);

extern void CurTempNums(char zero2nine, char zero2one);

extern void ClrCurTempNums(char zero2one);

extern void set_temp(int temp);

extern void initLCD(void);


#endif /* LCD_LIB_SD_H_ */
