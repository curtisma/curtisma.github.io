/*
 * Xbee_transceiver.h
 *
 * Port Map:
 *
 * X-Bee  -> MCU
 * pin 2  -> PA0 (RX)
 * pin 3  -> PA1 (TX)
 * pin 12 -> PA4 (CTS)
 * pin 16 -> PA3 (RTS)
 *
 *  Created on: Jan 28, 2011
 *      Author: Curtis
 */

#ifndef XBEE_TRANSCEIVER_H_
#define XBEE_TRANSCEIVER_H_

#include "usart.h"
#include "gpio.h"
#include "intc.h"
#include <avr32/io.h>
#include "compiler.h"
#include "board.h"


// User Interface Addresses


#define UI1_16bit_Address_MSB  0x01
#define UI2_16bit_Address_MSB  0x02
#define UI3_16bit_Address_MSB  0x03
#define UI4_16bit_Address_MSB  0x04
#define UI5_16bit_Address_MSB  0x05
#define TX_complete			   0x0A

// Need to set during configuration
#define Number_of_UIs          0x05
#define UI_current_16bit_Address_MSB UI1_16bit_Address_MSB

// RX_buffer/RX Queue - modified from the notes of Professor Zhang Zhao
#define DATA_SIZE 3		// Size of the buffer
#define RX_BUF_SIZE (DATA_SIZE+1)

//USART
#define USART_0               (&AVR32_USART1)
#define USART2                (&AVR32_USART2)
#define USART_RX_PIN          AVR32_USART1_RXD_0_0_PIN
#define USART_RX_FUNCTION     AVR32_USART1_RXD_0_0_FUNCTION
#define USART_TX_PIN          AVR32_USART1_TXD_0_0_PIN
#define USART_TX_FUNCTION     AVR32_USART1_TXD_0_0_FUNCTION
#define USART_IRQ             AVR32_USART1_IRQ
#define USART_BAUDRATE        57600
#define TARGET_PBACLK_FREQ_HZ FOSC0  // PBA clock target frequency, in Hz




/********************
 * Buffer functions *
 ********************/



typedef struct measurement_storage_struct {

	unsigned int curr_temp_measurement_UI[Number_of_UIs];
	unsigned int set_pt_measurement_UI[Number_of_UIs];

  } measurement_storage;


// Buffer_R was defined here
  typedef struct queue {
  volatile int tail;
  volatile unsigned char buf[RX_BUF_SIZE];
  volatile unsigned char newest_data;
  } Buffer_R;

Buffer_R *RX_Buffer;

//////////////////////////////////////////////////////////////////////
// Functions for the sending and receiving of the data using queues //
/////////////////////////////////////////////////////////////////////

// RX_buffer queue

// Initialize the RX_buffer (queue)
void init_queue(Buffer_R *q);

void init_measurement(measurement_storage *q);

// initializes the RX_Buffer
void init_RX_Buffer(void);


/* Gets data from the RX_Buffer
 * return -1 if queue is empty */
void dequeue(measurement_storage *q);

unsigned char dequeue_Rx_Buffer(void);



/////////////////////
// USART functions //
/////////////////////

/* USART interrupt handler
* Receives a USART message, byte by byte and adds it to the buffer to be parsed later
*/
#if __GNUC__
__attribute__((__interrupt__))
#elif __ICCAVR32__
__interrupt
#endif
static void usart_int_handler(void);



// Initialize the Xbee transceiver
void Init_Xbee(void);

///////////////////////
// Utility Functions //
///////////////////////

void request_data(int room);

void Send_Message_Transparent(int current_temp, int set_pt);

void Send_Message_Transparent_variable_length(int message_out[], int message_length);
#endif /* XBEE_TRANSCEIVER_H_ */


