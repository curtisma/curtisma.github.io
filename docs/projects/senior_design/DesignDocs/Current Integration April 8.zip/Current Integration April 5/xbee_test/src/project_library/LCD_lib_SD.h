#include "gpio.h"
#include "compiler.h"
#include "board.h"
#include "intc.h"
#include "pm.h"


//---------------------------------------------------------------
// CONSTANTS
//---------------------------------------------------------------

#define DISPOFF      0xAE
#define DISPON       0xAF
#define DISPSTART    0x40
#define PAGEADR      0xB0
#define COLADRL      0x00
#define COLADRH      0x10
#define ADCNORMAL    0xA0
#define ADCREVERSE   0xA1
#define COMNORMAL    0xC0
#define COMREVERSE   0xC8
#define DISPNORMAL   0xA6
#define DISPREVERSE  0xA7
#define LCDBIAS9     0xA2
#define LCDBIAS7     0xA3
#define RESET        0xE2
#define SETPOWERCTRL 0x2F
#define REGRESISTOR  0x27
#define SETCONTRAST  0x81
#define STATINDMODE  0xAC
#define BOOSTERRATIO 0xF8


//---------------------------------------------------------------
// PIN DEFINITION
//---------------------------------------------------------------

#define DOGCSPIN	AVR32_PIN_PA10     //stk600 pb2

#define DOGRESPIN	AVR32_PIN_PA19     //stk600 pc3

#define DOGA0PIN	AVR32_PIN_PA14     //stk600 pb6

#define DOGSCLPIN	AVR32_PIN_PA13     //stk600 pb5

#define DOGSIPIN	AVR32_PIN_PA12     //stk600 pb4


//---------------------------------------------------------------
// SPI SETUP DEFINITION
//---------------------------------------------------------------

#define SetBit(adr, bnr)	( (adr) |=  (1 << (bnr)) )
#define ClrBit(adr, bnr)	( (adr) &= ~(1 << (bnr)) )

#define	DOGENABLE  gpio_clr_gpio_pin(DOGCSPIN)
#define	DOGDISABLE gpio_set_gpio_pin(DOGCSPIN)

#define	DOGCOMMAND gpio_clr_gpio_pin(DOGA0PIN)
#define	DOGDATA    gpio_set_gpio_pin(DOGA0PIN)

#define	DOG_CLK_HIGH 	gpio_set_gpio_pin(DOGSCLPIN)
#define	DOG_CLK_LOW      gpio_clr_gpio_pin(DOGSCLPIN)

#define	DOG_SI_HIGH 	gpio_set_gpio_pin(DOGSIPIN)
#define	DOG_SI_LOW      gpio_clr_gpio_pin(DOGSIPIN)

#define DOG_RES			gpio_clr_gpio_pin(DOGRESPIN)
#define DOG_RES_DISB	gpio_set_gpio_pin(DOGRESPIN)


void dogSPIout(unsigned char out);
void initDOGM128(void);
void ResetDOG(void);
void DogKontrast(contrast);
void int2byte(int zeroTo255);
void PageSelect(unsigned char page);
void Reset(void);
void LineSelect(unsigned char line);
void ColumnSelect(unsigned char column);
void ClearDisplay(void);
void Display_ON(void);
void Display_OFF(void);
void ClearDisplay1(void);
void ISU_Logo(void);
void BATT_Charging(void);
void Template(void);
void BattLogo(void);
void BattLow(void);
void ClearBattLow(void);
void MON(void);
void TUE(void);
void WED(void);
void THUR(void);
void FRI(void);
void SAT(void);
void SUN(void);
void ClearDay(void);
void TimeNums(char zero2nine, char zero2three);
void AM_PM(char AM_Zero_Or_PM_One);
void semicolon(void);
void ClrTimeNums(char zero2three);
void SetTempNums(char zero2nine, char zero2one);
void ClrSetTempNums(char zero2one);
void CurTempNums(char zero2nine, char zero2one);
void ClrCurTempNums(char zero2one);
void promptDate(void);
void promptTime(void);
void initialSetupLCD(void);
void update_LCD_current_temp(unsigned char curTemp);
void update_LCD_set_pt(unsigned char setPt);
