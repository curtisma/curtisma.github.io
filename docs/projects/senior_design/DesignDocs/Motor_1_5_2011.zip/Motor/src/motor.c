
#include "compiler.h"
#include "gpio.h"
#include "board.h"
#include "intc.h"
#include "pwm.h"
#include "tc.h"
#include "pm.h"
#include "adc.h"




/*
 * Important notes on wiring the motor circuit
 * - Supply pin 9 on L298N with 5V
 * - Supply pin 4 on L298N with 12V
 * - Supply pin 1 on temp sensor with 3.3V
 * - Supply pin 3 on temp sensor with gnd
 *
 */


/*! \name Pin Configuration
 */
//! @{
#define GPIO_PIN_CHAN_A				AVR32_PIN_PA00			//Pin PA00 on STK600, connect to blue wire from encoder
#define GPIO_PIN_CHAN_B				AVR32_PIN_PA01			//Pin PA01 on STK600, connect to purple wire from encoder
#define GPIO_PIN_ENABLE				AVR32_PIN_PA02			//Pin PA02 on STK600, connect to pin 6 on L298N

#define PWM_PIN_INPUT_1				AVR32_PWM_0_PIN			//Pin PG03 on STK600, connect to pin 5 on L298N
#define PWM_PIN_INPUT_2				AVR32_PWM_1_PIN			//Pin PG04 on STK600, connect to pin 7 on L298N
#define PWM_FUNCTION_INPUT_1    	AVR32_PWM_0_FUNCTION
#define PWM_FUNCTION_INPUT_2    	AVR32_PWM_1_FUNCTION
#define PWM_CHANNEL_ID_INPUT_1  	0
#define PWM_CHANNEL_ID_INPUT_2  	1

#define GPIO_PIN_LED				AVR32_PIN_PA05			//Pin PA05 on STK600 for debugging purposes, connect to any LED

#define ADC_MOTOR_CURRENT_CHANNEL   0
#define ADC_MOTOR_CURRENT_PIN       AVR32_ADC_AD_0_PIN		//Pin PC05 on STK600, connect to pin 1 on L298N
#define ADC_MOTOR_CURRENT_FUNCTION  AVR32_ADC_AD_0_FUNCTION

#define ADC_TEMP_SENSOR_CHANNEL   	1
#define ADC_TEMP_SENSOR_PIN       	AVR32_ADC_AD_1_PIN		//Pin PC06 on STK600, connect to pin 2 on temp sensor
#define ADC_TEMP_SENSOR_FUNCTION  	AVR32_ADC_AD_1_FUNCTION



//! @}

/*	Global Variables
 *
 */

volatile int valvePosition;
volatile int slowDownFlag;
volatile int rotateCompleteFlag;

int valvePositionTarget;
int	slowDownMark;
int dutyCycle;

int motorSpeedFast  = 20;
int motorSpeedSlow  = 15;

double adc_resolution = (3.3/1024);				//ADC uses 3.3V as reference and is only 10-bit (1024)





/*
 * brief The read Channel A interrupt handler.
 */
#if __GNUC__
__attribute__((__interrupt__))
#elif __ICCAVR32__
__interrupt
#endif



/*
 *
 *	Keep track of valve movement
 *
 */
static void readChanA(void) {

	//Checks to see if channel A stays low for a valid pulse
	if (gpio_get_pin_value(GPIO_PIN_CHAN_A) == 0) {

		if(gpio_get_pin_value(GPIO_PIN_CHAN_B) == 1)	{
			++valvePosition;
		}

		if(gpio_get_pin_value(GPIO_PIN_CHAN_B) == 0)	{
			--valvePosition;
		}

	}

	// Check for slow down mark
	if (valvePosition == slowDownMark)	{
		dutyCycle = motorSpeedSlow;
		slowDownFlag = 1;
	}

	// Check for final position
	if (valvePosition == valvePositionTarget)	{
		gpio_clr_gpio_pin(GPIO_PIN_ENABLE);
		rotateCompleteFlag = 1;
	}

	gpio_clear_pin_interrupt_flag(GPIO_PIN_CHAN_A);

}


/*
 *
 * Set up interrupts
 *
 */
void initInterrupt(void){

	/* Disable all interrupts */
	Disable_global_interrupt();

	gpio_enable_pin_interrupt(GPIO_PIN_CHAN_A, GPIO_FALLING_EDGE);

	// Initialize interrupt vectors.
	INTC_init_interrupts();

	/* register readChanA on level 1 */
	INTC_register_interrupt(&readChanA, AVR32_GPIO_IRQ_0,
			 AVR32_INTC_INT1);

	/* Enable all interrupts */
	Enable_global_interrupt();

}




/*
 *
 * Set output for PWM channel
 *
 */
void startPWM(unsigned int CHANNEL_ID, unsigned int PWM_PIN, unsigned int PWM_FUNCTION, int PWM_DUTYCYCLE){

	  pwm_opt_t pwm_opt;                                // PWM option config.
	  avr32_pwm_channel_t pwm_channel = { .ccnt = 0 };  // One channel config.

	  // The channel number and instance is used in several functions.
	  // It's defined as local variable for ease-of-use.
	  unsigned int channel_id;

	  channel_id = CHANNEL_ID;
	  gpio_enable_module_pin(PWM_PIN, PWM_FUNCTION);

	  // PWM controller configuration.
	  pwm_opt.diva = AVR32_PWM_DIVA_CLK_OFF;
	  pwm_opt.divb = AVR32_PWM_DIVB_CLK_OFF;
	  pwm_opt.prea = AVR32_PWM_PREA_MCK;
	  pwm_opt.preb = AVR32_PWM_PREB_MCK;

	  pwm_init(&pwm_opt);

	  pwm_channel.CMR.calg = PWM_MODE_LEFT_ALIGNED;       // Channel mode.
	  pwm_channel.CMR.cpol = PWM_POLARITY_HIGH;            // Channel polarity.
	  pwm_channel.CMR.cpd = PWM_UPDATE_DUTY;              // Not used the first time.
	  pwm_channel.CMR.cpre = AVR32_PWM_CPRE_MCK_DIV_256;  // Channel prescaler.
	  pwm_channel.cdty = PWM_DUTYCYCLE;   // Channel duty cycle, should be < CPRD.
	  pwm_channel.cprd = 20;  // Channel period.
	  pwm_channel.cupd = 0;   // Channel update is not used here.
	  // With these settings, the output waveform period will be :
	  // (115200/256)/20 == 22.5Hz == (MCK/prescaler)/period, with MCK == 115200Hz,
	  // prescaler == 256, period == 20.

	  pwm_channel_init(channel_id, &pwm_channel); // Set channel configuration to channel 0.
	  pwm_start_channels(1 << channel_id);

}



/*
 *
 * Disable PWM channel
 *
 */
void stopPWM(unsigned int CHANNEL_ID, unsigned int PWM_PIN, unsigned int PWM_FUNCTION){

	  pwm_opt_t pwm_opt;                                // PWM option config.
	  avr32_pwm_channel_t pwm_channel = { .ccnt = 0 };  // One channel config.

	  // The channel number and instance is used in several functions.
	  // It's defined as local variable for ease-of-use.
	  unsigned int channel_id;

	  channel_id = CHANNEL_ID;
	  gpio_enable_module_pin(PWM_PIN, PWM_FUNCTION);

	  // PWM controller configuration.
	  pwm_opt.diva = AVR32_PWM_DIVA_CLK_OFF;
	  pwm_opt.divb = AVR32_PWM_DIVB_CLK_OFF;
	  pwm_opt.prea = AVR32_PWM_PREA_MCK;
	  pwm_opt.preb = AVR32_PWM_PREB_MCK;

	  pwm_init(&pwm_opt);

	  pwm_channel.CMR.calg = PWM_MODE_LEFT_ALIGNED;       // Channel mode.
	  pwm_channel.CMR.cpol = PWM_POLARITY_LOW;            // Channel polarity.
	  pwm_channel.CMR.cpd = PWM_UPDATE_DUTY;              // Not used the first time.
	  pwm_channel.CMR.cpre = AVR32_PWM_CPRE_MCK_DIV_256;  // Channel prescaler.
	  pwm_channel.cdty = 0;   // Channel duty cycle, should be < CPRD.
	  pwm_channel.cprd = 20;  // Channel period.
	  pwm_channel.cupd = 0;   // Channel update is not used here.
	  // With these settings, the output waveform period will be :
	  // (115200/256)/20 == 22.5Hz == (MCK/prescaler)/period, with MCK == 115200Hz,
	  // prescaler == 256, period == 20.

	  pwm_channel_init(channel_id, &pwm_channel); // Set channel configuration to channel 0.
	  pwm_stop_channels(1 << channel_id);

}


/*
 * Important notes
 * - Remove the jumper for AREF0 in the blue zone
 * - Provide the AREF0 pin on the STK600 with 3.3V with 1.0uF and 10nF bypass capacitors
 * - Connect ground of the STK600 with ground of power supply
 * - 10 bit ADC, return value range from 0 - 1023
 *
 */
signed short readADC(unsigned int ADC_CHANNEL, unsigned int ADC_PIN, unsigned int ADC_FUNCTION){

	  // GPIO pin/adc-function map.
	  const gpio_map_t ADC_GPIO_MAP = {ADC_PIN, ADC_FUNCTION};

	  volatile avr32_adc_t *adc = &AVR32_ADC;

	  signed short adc_value = -1;

	  unsigned short adc_channel = ADC_CHANNEL;

	  // switch to oscillator 0
	  pm_switch_to_osc0(&AVR32_PM, FOSC0, OSC0_STARTUP);


	  // Assign and enable GPIO pins to the ADC function.
	  gpio_enable_module(ADC_GPIO_MAP, sizeof(ADC_GPIO_MAP) / sizeof(ADC_GPIO_MAP[0]));

	  // configure ADC
	  // Lower the ADC clock to match the ADC characteristics (because we configured
	  // the CPU clock to 20MHz, and the ADC clock characteristics are usually lower;
	  // cf. the ADC Characteristic section in the datasheet).
	  AVR32_ADC.mr |= 0x1 << AVR32_ADC_MR_PRESCAL_OFFSET;
	  adc_configure(adc);

	  adc_enable(adc,adc_channel);

	  int ready = 0;

	  adc_start(adc);

	  //Wait until the conversion is completed
	  while(ready == 0){

		  if(adc_check_eoc(adc, adc_channel) == 1){
			  ready = 1;
		  }

	  }

	  adc_value = adc_get_value(adc, adc_channel);

	  adc_disable(adc,adc_channel);

	  return adc_value;
}


/*
 *
 * Check for overcurrent in the motor
 *
 */
bool checkOverCurrent(void){

	double current_sense_res = 1.380;

	double adc_value = readADC(ADC_MOTOR_CURRENT_CHANNEL, ADC_MOTOR_CURRENT_PIN, ADC_MOTOR_CURRENT_FUNCTION);


	double motor_current = (adc_resolution*adc_value)/current_sense_res;

	if (motor_current >= 1.40){
		return true;
	}

	return false;

}


/*
 *
 * Initialize variables for motor control
 * Need to run once before calling rotateMotor function.
 *
 */
void initMotor(void){
	gpio_clr_gpio_pin(GPIO_PIN_ENABLE);
	initInterrupt();
	valvePosition = 0;
}



/*
 * Need to call function initMotor once before use.
 *
 * Rotate motor
 * - dir = 0 , CW
 * - dir = 1,  CCW
 *
 *
 */
bool rotateMotor(double degree, int dir){

	// Recovering the missing 24 pulses
	double calibrationFactor = 1.09;

	//Reset flags.
	valvePositionTarget = 0;
	rotateCompleteFlag = 0;
	slowDownFlag = 0;


	//Uses slow speed when turning at low degrees. Otherwise fast speed.
	if(degree > 180){
		dutyCycle = motorSpeedFast;
	} else {
		dutyCycle = motorSpeedSlow;
	}


	// Set the direction of turn and final position.
	if(dir == 1){
		stopPWM(PWM_CHANNEL_ID_INPUT_1, PWM_PIN_INPUT_1, PWM_FUNCTION_INPUT_1);
		startPWM(PWM_CHANNEL_ID_INPUT_2, PWM_PIN_INPUT_2, PWM_FUNCTION_INPUT_2, dutyCycle);

		valvePositionTarget = valvePosition - calibrationFactor*degree;
		slowDownMark = valvePosition - calibrationFactor*degree*0.75;

	} else if (dir == 0){
		stopPWM(PWM_CHANNEL_ID_INPUT_2, PWM_PIN_INPUT_2, PWM_FUNCTION_INPUT_2);
		startPWM(PWM_CHANNEL_ID_INPUT_1, PWM_PIN_INPUT_1, PWM_FUNCTION_INPUT_1, dutyCycle);

		valvePositionTarget = valvePosition + calibrationFactor*degree;
		slowDownMark = valvePosition + calibrationFactor*degree*0.75;

	}


	// Ensure the final valve position is valid between fully close and fully open.
	if(valvePositionTarget < 0 || valvePositionTarget > 1962){
		return false;
	}


	// Enable motor
	gpio_set_gpio_pin(GPIO_PIN_ENABLE);

	// Wait until the turn is complete
	while(rotateCompleteFlag != 1){

		// Checks for overcurrent
		if(checkOverCurrent()){
			gpio_clr_gpio_pin(GPIO_PIN_ENABLE);
			return false;
		}

		// Slow down the motor when it reaches 75% of its final position.
		if(slowDownFlag == 1){

			if(dir == 1){
				stopPWM(PWM_CHANNEL_ID_INPUT_1, PWM_PIN_INPUT_1, PWM_FUNCTION_INPUT_1);
				startPWM(PWM_CHANNEL_ID_INPUT_2, PWM_PIN_INPUT_2, PWM_FUNCTION_INPUT_2, dutyCycle);

			} else if (dir == 0){
				stopPWM(PWM_CHANNEL_ID_INPUT_2, PWM_PIN_INPUT_2, PWM_FUNCTION_INPUT_2);
				startPWM(PWM_CHANNEL_ID_INPUT_1, PWM_PIN_INPUT_1, PWM_FUNCTION_INPUT_1, dutyCycle);

			}
		}


	}

	return true;

}



/*
 *
 * Convert Celsius to Fahrenheit
 *
 */
int cel2Fahr(double celsius){

	int fahr = celsius*(9/5) + 32;

	return fahr;

}


/*
 *
 * Read temperature from temp sensor
 *
 */
int readTemp(void){

	//These parameters will need to be confirmed by testing with using the STK600
	double temp_sensor_bias = 424;			// at zero degrees celsius, temp sensor outputs 424mV
	double temp_sensor_slope = 6.25;		// rate of 6.25mV/celsius


	double adc_value = readADC(ADC_TEMP_SENSOR_CHANNEL, ADC_TEMP_SENSOR_PIN, ADC_TEMP_SENSOR_FUNCTION);

	double temp_sensor_volt = (adc_value*adc_resolution)*1000; // return voltage reading in mV

	double temp_celsius = (temp_sensor_volt - temp_sensor_bias)/temp_sensor_slope;

	int temp_fahr = cel2Fahr(temp_celsius);

	return temp_fahr;

}


int main(void)
{

	while (1)
	{
	    // If there is a chance that any PB write operations are incomplete, the CPU
	    // should perform a read operation from any register on the PB bus before
	    // executing the sleep instruction.
	    AVR32_INTC.ipr[0];  // Dummy read

	    // Go to FROZEN sleep mode.
	    SLEEP(AVR32_PM_SMODE_FROZEN);

	}

}




